#include "windows.h"

void main()
{
    MessageBoxA(NULL, "Hello :)", "main()", MB_OK);
}